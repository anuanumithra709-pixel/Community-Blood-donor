const express = require('express');
const path = require('path');
const Database = require('better-sqlite3');

const app = express();
const PORT = process.env.PORT || 3000;
const db = new Database(path.join(__dirname, 'blood_donor.db'));

db.exec(`
CREATE TABLE IF NOT EXISTS donors (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 blood TEXT NOT NULL,
 location TEXT,
 latitude REAL NOT NULL,
 longitude REAL NOT NULL,
 availability TEXT NOT NULL DEFAULT 'Available',
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS requests (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 blood TEXT NOT NULL,
 location TEXT,
 latitude REAL NOT NULL,
 longitude REAL NOT NULL,
 units INTEGER NOT NULL,
 details TEXT,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS feedback (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT,
 rating INTEGER NOT NULL,
 message TEXT,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
`);

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

function haversine(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const toRad = d => d * Math.PI / 180;
  const dLat = toRad(lat2-lat1), dLon = toRad(lon2-lon1);
  const a = Math.sin(dLat/2)**2 + Math.cos(toRad(lat1))*Math.cos(toRad(lat2))*Math.sin(dLon/2)**2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
}

app.get('/api/donors', (req,res) => {
  res.json(db.prepare('SELECT * FROM donors ORDER BY id DESC').all());
});

app.post('/api/donors', (req,res) => {
  const {name,blood,location,latitude,longitude,availability='Available'} = req.body;
  if(!name || !blood || !Number.isFinite(Number(latitude)) || !Number.isFinite(Number(longitude)))
    return res.status(400).json({error:'Name, blood group, latitude and longitude are required.'});
  const info = db.prepare(`INSERT INTO donors(name,blood,location,latitude,longitude,availability) VALUES(?,?,?,?,?,?)`)
    .run(name,blood,location||'Not specified',Number(latitude),Number(longitude),availability);
  res.json({id:info.lastInsertRowid,message:'Donor saved successfully.'});
});

app.post('/api/requests', (req,res) => {
  const {blood,location,latitude,longitude,units=1,details=''} = req.body;
  if(!blood || !Number.isFinite(Number(latitude)) || !Number.isFinite(Number(longitude)))
    return res.status(400).json({error:'Blood group, latitude and longitude are required.'});
  const info = db.prepare(`INSERT INTO requests(blood,location,latitude,longitude,units,details) VALUES(?,?,?,?,?,?)`)
    .run(blood,location||'Not specified',Number(latitude),Number(longitude),Math.max(1,Number(units)||1),details);
  const donors = db.prepare(`SELECT * FROM donors WHERE blood=? AND availability='Available'`).all(blood);
  const matches = donors.map(d => ({...d,distance_km:Number(haversine(Number(latitude),Number(longitude),d.latitude,d.longitude).toFixed(2))}))
    .sort((a,b)=>a.distance_km-b.distance_km);
  res.json({request_id:info.lastInsertRowid,matches});
});

app.get('/api/feedback', (req,res) => res.json(db.prepare('SELECT * FROM feedback ORDER BY id DESC').all()));
app.post('/api/feedback', (req,res) => {
  const {name='',rating,message=''} = req.body;
  const r=Number(rating);
  if(!Number.isInteger(r) || r<1 || r>5 || !message) return res.status(400).json({error:'Rating 1-5 and feedback message are required.'});
  const info=db.prepare('INSERT INTO feedback(name,rating,message) VALUES(?,?,?)').run(name,r,message);
  res.json({id:info.lastInsertRowid,message:'Feedback saved.'});
});

app.get('/api/stats', (req,res) => {
  res.json({donors:db.prepare('SELECT COUNT(*) c FROM donors').get().c,requests:db.prepare('SELECT COUNT(*) c FROM requests').get().c,feedback:db.prepare('SELECT COUNT(*) c FROM feedback').get().c});
});

app.listen(PORT,()=>console.log(`Community Blood Donor Finder running at http://localhost:${PORT}`));
