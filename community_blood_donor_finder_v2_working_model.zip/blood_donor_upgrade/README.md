# Community Blood Donor Finder v2.0

Improved college project prototype based on the original client-side model.

## Improvements implemented
1. Node.js + Express backend API.
2. SQLite persistent database for donors, requests and feedback.
3. Haversine formula for actual coordinate-based distance calculation in kilometres.
4. Matching = exact blood group + Available status, then nearest-distance sorting.
5. User feedback form stored in the database.
6. Admin dashboard reads persistent donor/request/feedback data.

## Run locally
1. Install Node.js 18+.
2. Open this folder in a terminal.
3. Run `npm install`.
4. Run `npm start`.
5. Open `http://localhost:3000`.

The database file `blood_donor.db` is created automatically on first run.

## Important scope
This is an educational coordination system. It does not perform medical screening, donor eligibility decisions, blood-bank verification, or transfusion compatibility decisions. Those steps remain with qualified healthcare professionals/blood-bank staff.
